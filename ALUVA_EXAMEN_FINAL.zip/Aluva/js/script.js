document.addEventListener("DOMContentLoaded", function () {
  // Año automático en el pie de página.
  const yearElement = document.getElementById("currentYear");
  if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
  }

  // Mensaje visual reutilizable para confirmaciones y validaciones.
  function showMessage(message, type) {
    let box = document.getElementById("siteMessage");
    if (!box) {
      box = document.createElement("div");
      box.id = "siteMessage";
      box.className = "site-message";
      document.body.appendChild(box);
    }
    box.className = "site-message " + (type || "success");
    box.textContent = message;
    box.classList.add("show");
    clearTimeout(window.siteMessageTimer);
    window.siteMessageTimer = setTimeout(function () {
      box.classList.remove("show");
    }, 4500);
  }

  // Evento submit: formulario de personalización.
  const personalizationForm = document.getElementById("personalizationForm");
  if (personalizationForm) {
    personalizationForm.addEventListener("submit", function (event) {
      event.preventDefault();

      const name = document.getElementById("nombreCliente").value.trim();
      const product = document.getElementById("producto").value;
      const size = document.getElementById("talla").value;
      const detail = document.getElementById("detalle").value.trim();

      if (name.length < 2) {
        showMessage("Ingresa un nombre válido para continuar.", "error");
        document.getElementById("nombreCliente").focus();
        return;
      }

      if (detail.length < 5) {
        showMessage("Describe brevemente la personalización solicitada.", "error");
        document.getElementById("detalle").focus();
        return;
      }

      const phone = "56912345678";
      const text =
        "Hola ALUVA, quiero solicitar una personalización.%0A" +
        "Nombre: " + encodeURIComponent(name) + "%0A" +
        "Producto: " + encodeURIComponent(product) + "%0A" +
        "Talla: " + encodeURIComponent(size) + "%0A" +
        "Detalle: " + encodeURIComponent(detail);

      showMessage("Solicitud validada. Abriendo WhatsApp...", "success");
      window.open("https://wa.me/" + phone + "?text=" + text, "_blank", "noopener,noreferrer");
    });
  }

  // Evento submit: formulario de contacto.
  const contactForm = document.getElementById("contactForm");
  if (contactForm) {
    contactForm.addEventListener("submit", function (event) {
      event.preventDefault();

      const name = document.getElementById("nombre").value.trim();
      const email = document.getElementById("correo").value.trim();
      const message = document.getElementById("mensaje").value.trim();

      if (name.length < 2 || message.length < 5) {
        showMessage("Completa correctamente nombre y mensaje.", "error");
        return;
      }

      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        showMessage("Ingresa un correo electrónico válido.", "error");
        document.getElementById("correo").focus();
        return;
      }

      const subject = encodeURIComponent("Contacto desde sitio web ALUVA");
      const body = encodeURIComponent(
        "Nombre: " + name + "\nCorreo: " + email + "\n\nMensaje:\n" + message
      );

      showMessage("Datos validados. Se abrirá tu cliente de correo.", "success");
      window.location.href =
        "mailto:aluva.seguridad@gmail.com?subject=" + subject + "&body=" + body;
    });
  }

  // Evento click: galería con visualización ampliada.
  document.querySelectorAll(".gallery-card img").forEach(function (image) {
    image.addEventListener("click", function () {
      const modalImage = document.getElementById("galleryModalImage");
      const modalTitle = document.getElementById("galleryModalTitle");
      if (modalImage) {
        modalImage.src = image.src;
        modalImage.alt = image.alt;
      }
      if (modalTitle) {
        modalTitle.textContent = image.alt;
      }
      if (window.jQuery && window.jQuery.fn.modal) {
        window.jQuery("#galleryModal").modal("show");
      } else {
        showMessage("La imagen seleccionada: " + image.alt, "success");
      }
    });
  });

  // Evento click: botón volver arriba.
  const backToTop = document.getElementById("backToTop");
  if (backToTop) {
    window.addEventListener("scroll", function () {
      backToTop.classList.toggle("visible", window.scrollY > 500);
    });

    backToTop.addEventListener("click", function () {
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  // Evento click: cerrar el menú móvil después de seleccionar una sección.
  document.querySelectorAll("#navbarALUVA .nav-link").forEach(function (link) {
    link.addEventListener("click", function () {
      const menu = document.getElementById("navbarALUVA");
      if (window.innerWidth < 992 && menu && window.jQuery) {
        window.jQuery(menu).collapse("hide");
      }
    });
  });
});
